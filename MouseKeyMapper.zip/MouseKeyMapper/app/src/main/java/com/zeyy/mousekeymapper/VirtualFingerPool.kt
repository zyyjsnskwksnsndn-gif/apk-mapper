package com.zeyy.mousekeymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper

/**
 * Satu "finger" = satu stroke yang terus di-continue tiap tick (TICK_MS),
 * jadi gerakan mouse/keyboard bisa nge-drag touch secara real-time tanpa
 * nunggu stroke lama selesai. Semua finger aktif dikirim bareng tiap tick
 * supaya multi-touch-nya kebaca simultan oleh game (gerak+tembak+look bareng).
 */
class VirtualFingerPool(private val service: AccessibilityService) {

    private class Finger {
        var curX = 0f
        var curY = 0f
        var down = false
        var lastStroke: GestureDescription.StrokeDescription? = null
        var dirty = false
    }

    private val fingers = HashMap<String, Finger>()
    private val handler = Handler(Looper.getMainLooper())
    private var ticking = false

    private val tick = object : Runnable {
        override fun run() {
            flush()
            if (fingers.values.any { it.down }) {
                handler.postDelayed(this, TICK_MS)
            } else {
                ticking = false
            }
        }
    }

    private fun ensureTicking() {
        if (!ticking) {
            ticking = true
            handler.postDelayed(tick, TICK_MS)
        }
    }

    fun press(id: String, x: Float, y: Float) {
        val f = fingers.getOrPut(id) { Finger() }
        f.curX = x; f.curY = y; f.down = true; f.dirty = true
        f.lastStroke = null // mulai stroke baru
        ensureTicking()
        flush() // langsung dispatch down, jangan tunggu tick berikutnya
    }

    fun moveTo(id: String, x: Float, y: Float) {
        val f = fingers[id] ?: return
        if (!f.down) return
        f.curX = x; f.curY = y; f.dirty = true
        ensureTicking()
    }

    fun release(id: String) {
        val f = fingers[id] ?: return
        if (!f.down) return
        val path = Path().apply { moveTo(f.curX, f.curY) }
        val prev = f.lastStroke
        val stroke = if (prev != null) {
            GestureDescription.StrokeDescription.continueStroke(prev, path, 0, UP_DURATION, false)
        } else {
            GestureDescription.StrokeDescription(path, 0, UP_DURATION, false)
        }
        dispatchSingle(stroke)
        f.down = false
        f.lastStroke = null
        fingers.remove(id)
    }

    private fun flush() {
        val dirtyFingers = fingers.values.filter { it.down && it.dirty }
        if (dirtyFingers.isEmpty()) return

        val builder = GestureDescription.Builder()
        for (f in dirtyFingers) {
            val path = Path().apply { moveTo(f.curX, f.curY) }
            val prev = f.lastStroke
            val stroke = if (prev == null) {
                GestureDescription.StrokeDescription(path, 0, TICK_MS, true)
            } else {
                GestureDescription.StrokeDescription.continueStroke(prev, path, 0, TICK_MS, true)
            }
            f.lastStroke = stroke
            f.dirty = false
            builder.addStroke(stroke)
        }
        service.dispatchGesture(builder.build(), null, null)
    }

    private fun dispatchSingle(stroke: GestureDescription.StrokeDescription) {
        val builder = GestureDescription.Builder()
        builder.addStroke(stroke)
        service.dispatchGesture(builder.build(), null, null)
    }

    /** tap sekali (buat jump/reload) tanpa perlu hold */
    fun tap(x: Float, y: Float, durationMs: Long = 50) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs, false)
        dispatchSingle(stroke)
    }

    companion object {
        private const val TICK_MS = 35L
        private const val UP_DURATION = 1L
    }
}
