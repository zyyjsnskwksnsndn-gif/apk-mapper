package com.zeyy.mousekeymapper

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 120, 60, 60)
        }

        root.addView(TextView(this).apply {
            text = "Mouse+Key Mapper\n\n" +
                "1. Tap tombol di bawah, aktifkan service ini di daftar Accessibility.\n" +
                "2. Kembali ke sini, buka Free Fire.\n" +
                "3. Tombol bulat kecil melayang = toggle edit layout (geser posisi joystick/tombol tembak/jump/dll).\n" +
                "4. Colok/sambungin keyboard+mouse bluetooth, langsung jalan."
            textSize = 15f
        })

        root.addView(Button(this).apply {
            text = "Buka Settings Accessibility"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        setContentView(root)
    }
}
