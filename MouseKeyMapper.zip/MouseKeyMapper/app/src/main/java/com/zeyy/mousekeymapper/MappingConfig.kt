package com.zeyy.mousekeymapper

import android.content.Context
import org.json.JSONObject

data class Zone(var x: Float, var y: Float, var radius: Float)

/**
 * Semua posisi disimpan dalam PERSEN layar (0f..1f), biar aman dipakai
 * di device/resolusi apa saja. Dikonversi ke pixel saat dipakai.
 */
object MappingConfig {

    private const val PREFS = "mapper_zones"

    // default layout: joystick gerak kiri-bawah, tombol kanan-bawah ala FF
    var moveJoystick = Zone(0.18f, 0.78f, 0.11f)
    var lookAnchor   = Zone(0.72f, 0.45f, 0.09f)   // area "layar look" (drag kanan)
    var fireZone     = Zone(0.88f, 0.80f, 0.07f)
    var scopeZone    = Zone(0.88f, 0.60f, 0.055f)
    var jumpZone     = Zone(0.80f, 0.85f, 0.055f)
    var crouchZone   = Zone(0.65f, 0.90f, 0.05f)
    var reloadZone   = Zone(0.70f, 0.70f, 0.05f)

    fun allZones(): Map<String, Zone> = linkedMapOf(
        "move" to moveJoystick,
        "look" to lookAnchor,
        "fire" to fireZone,
        "scope" to scopeZone,
        "jump" to jumpZone,
        "crouch" to crouchZone,
        "reload" to reloadZone
    )

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = p.getString("json", null) ?: return
        val obj = JSONObject(raw)
        allZones().forEach { (key, zone) ->
            if (obj.has(key)) {
                val z = obj.getJSONObject(key)
                zone.x = z.getDouble("x").toFloat()
                zone.y = z.getDouble("y").toFloat()
                zone.radius = z.getDouble("r").toFloat()
            }
        }
    }

    fun save(ctx: Context) {
        val obj = JSONObject()
        allZones().forEach { (key, zone) ->
            val z = JSONObject()
            z.put("x", zone.x); z.put("y", zone.y); z.put("r", zone.radius)
            obj.put(key, z)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("json", obj.toString()).apply()
    }

    // sensitivitas look (mouse -> drag), dan deadzone joystick gerak
    var lookSensitivity = 2.4f
    var lookResetRadiusPx = 220f   // sejauh ini finger "look" lift & re-press (trik infinite drag)
}
