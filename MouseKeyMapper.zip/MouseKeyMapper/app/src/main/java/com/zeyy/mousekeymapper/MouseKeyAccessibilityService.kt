package com.zeyy.mousekeymapper

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.util.DisplayMetrics
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class MouseKeyAccessibilityService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var fingers: VirtualFingerPool
    private var screenW = 0f
    private var screenH = 0f

    // state keyboard gerak
    private val wasd = BooleanArray(4) // W A S D
    private var crouchHeld = false

    // state look (trik recenter)
    private var lookOffX = 0f
    private var lookOffY = 0f
    private var lookDown = false

    private var captureView: CaptureView? = null
    private var editOverlay: FrameLayout? = null
    private var toggleBtn: View? = null
    private var editMode = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        fingers = VirtualFingerPool(this)
        MappingConfig.load(this)

        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels.toFloat()
        screenH = dm.heightPixels.toFloat()

        addCaptureWindow()
        addToggleButton()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ----------------------------------------------------------------
    // KEYBOARD (bluetooth) - API resmi accessibility buat filter key event
    // ----------------------------------------------------------------
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (editMode) return false // biar ga ganggu pas lagi atur layout

        val down = event.action == KeyEvent.ACTION_DOWN
        when (event.keyCode) {
            KeyEvent.KEYCODE_W -> { wasd[0] = down; updateMove(); return true }
            KeyEvent.KEYCODE_A -> { wasd[1] = down; updateMove(); return true }
            KeyEvent.KEYCODE_S -> { wasd[2] = down; updateMove(); return true }
            KeyEvent.KEYCODE_D -> { wasd[3] = down; updateMove(); return true }

            KeyEvent.KEYCODE_SPACE -> {
                if (down && event.repeatCount == 0) {
                    val z = MappingConfig.jumpZone
                    fingers.tap(z.x * screenW, z.y * screenH)
                }
                return true
            }
            KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_CTRL_LEFT -> {
                if (down && !crouchHeld) {
                    crouchHeld = true
                    val z = MappingConfig.crouchZone
                    fingers.press("crouch", z.x * screenW, z.y * screenH)
                } else if (!down && crouchHeld) {
                    crouchHeld = false
                    fingers.release("crouch")
                }
                return true
            }
            KeyEvent.KEYCODE_R -> {
                if (down && event.repeatCount == 0) {
                    val z = MappingConfig.reloadZone
                    fingers.tap(z.x * screenW, z.y * screenH)
                }
                return true
            }
        }
        return false // key lain diteruskan normal
    }

    private fun updateMove() {
        val z = MappingConfig.moveJoystick
        val cx = z.x * screenW
        val cy = z.y * screenH
        val r = z.radius * min(screenW, screenH)

        var dx = 0f; var dy = 0f
        if (wasd[0]) dy -= 1f   // W
        if (wasd[2]) dy += 1f   // S
        if (wasd[1]) dx -= 1f   // A
        if (wasd[3]) dx += 1f   // D

        val active = dx != 0f || dy != 0f
        val id = "move"
        if (!active) {
            fingers.release(id)
            return
        }
        val len = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        val nx = dx / len; val ny = dy / len
        val tx = cx + nx * r * 0.9f
        val ty = cy + ny * r * 0.9f

        if (!isPressed(id)) fingers.press(id, cx, cy)
        fingers.moveTo(id, tx, ty)
    }

    private val pressedIds = HashSet<String>()
    private fun isPressed(id: String): Boolean {
        // VirtualFingerPool ga expose state publik, jadi dilacak lokal di sini
        return pressedIds.contains(id).also { }
    }

    // ----------------------------------------------------------------
    // CAPTURE WINDOW - fokus kecil buat requestPointerCapture (mouse)
    // ----------------------------------------------------------------
    private fun addCaptureWindow() {
        val view = CaptureView(this)
        captureView = view
        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0; lp.y = 0
        wm.addView(view, lp)
        view.post { view.requestFocus(); view.requestPointerCapture() }
    }

    private inner class CaptureView(ctx: android.content.Context) : View(ctx) {
        init { isFocusable = true; isFocusableInTouchMode = true }

        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus) requestPointerCapture()
        }

        override fun onCapturedMotionEvent(event: MotionEvent): Boolean {
            if (editMode) return false
            handleMouseDelta(
                event.getAxisValue(MotionEvent.AXIS_RELATIVE_X),
                event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y)
            )
            return true
        }

        override fun onGenericMotionEvent(event: MotionEvent): Boolean {
            if (editMode) return false
            if (event.source and InputDevice.SOURCE_CLASS_BUTTON != 0 ||
                event.actionButton != 0
            ) {
                when (event.action) {
                    MotionEvent.ACTION_BUTTON_PRESS -> handleMouseButton(event.actionButton, true)
                    MotionEvent.ACTION_BUTTON_RELEASE -> handleMouseButton(event.actionButton, false)
                }
            }
            return true
        }
    }

    private fun handleMouseButton(button: Int, down: Boolean) {
        when (button) {
            MotionEvent.BUTTON_PRIMARY -> {
                val z = MappingConfig.fireZone
                if (down) { fingers.press("fire", z.x * screenW, z.y * screenH); pressedIds.add("fire") }
                else { fingers.release("fire"); pressedIds.remove("fire") }
            }
            MotionEvent.BUTTON_SECONDARY -> {
                val z = MappingConfig.scopeZone
                if (down) { fingers.press("scope", z.x * screenW, z.y * screenH); pressedIds.add("scope") }
                else { fingers.release("scope"); pressedIds.remove("scope") }
            }
        }
    }

    // trik "recenter": finger look lift & pasang ulang tiap ngelewatin radius,
    // biar muter kamera ga kebentur tepi layar (infinite drag ala mouse-look).
    private fun handleMouseDelta(dx: Float, dy: Float) {
        if (dx == 0f && dy == 0f) return
        val z = MappingConfig.lookAnchor
        val anchorX = z.x * screenW
        val anchorY = z.y * screenH

        lookOffX += dx * MappingConfig.lookSensitivity
        lookOffY += dy * MappingConfig.lookSensitivity

        val id = "look"
        if (!lookDown) {
            fingers.press(id, anchorX, anchorY)
            lookDown = true
        }
        fingers.moveTo(id, anchorX + lookOffX, anchorY + lookOffY)

        val dist = hypot(lookOffX.toDouble(), lookOffY.toDouble()).toFloat()
        if (dist > MappingConfig.lookResetRadiusPx) {
            fingers.release(id)
            lookDown = false
            lookOffX = 0f; lookOffY = 0f
            // finger baru dipasang lagi di tick berikutnya begitu delta mouse lanjut masuk
        }
    }

    // ----------------------------------------------------------------
    // TOGGLE BUTTON + EDIT OVERLAY (atur posisi joystick/tombol)
    // ----------------------------------------------------------------
    private fun addToggleButton() {
        val btn = View(this).apply {
            setBackgroundColor(Color.parseColor("#8800BCD4"))
        }
        toggleBtn = btn
        val size = (screenW * 0.1f).toInt().coerceIn(90, 160)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 20; lp.y = 200

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        btn.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = lp.x; startY = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val ddx = ev.rawX - downX; val ddy = ev.rawY - downY
                    if (max(kotlin.math.abs(ddx), kotlin.math.abs(ddy)) > 12f) moved = true
                    lp.x = startX + ddx.toInt(); lp.y = startY + ddy.toInt()
                    wm.updateViewLayout(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleEditMode()
                    true
                }
                else -> false
            }
        }
        wm.addView(btn, lp)
    }

    private fun toggleEditMode() {
        editMode = !editMode
        if (editMode) showEditOverlay() else hideEditOverlay()
    }

    private fun showEditOverlay() {
        val overlay = FrameLayout(this)
        editOverlay = overlay
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(overlay, lp)

        MappingConfig.allZones().forEach { (key, zone) ->
            val dotSize = (zone.radius * min(screenW, screenH) * 2).toInt().coerceAtLeast(60)
            val dot = View(this).apply {
                setBackgroundColor(Color.argb(140, 255, 80, 0))
            }
            val dp = FrameLayout.LayoutParams(dotSize, dotSize)
            dp.leftMargin = (zone.x * screenW - dotSize / 2).toInt()
            dp.topMargin = (zone.y * screenH - dotSize / 2).toInt()
            overlay.addView(dot, dp)

            dot.setOnTouchListener { v, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_MOVE -> {
                        val lp2 = v.layoutParams as FrameLayout.LayoutParams
                        lp2.leftMargin = (ev.rawX - dotSize / 2).toInt()
                        lp2.topMargin = (ev.rawY - dotSize / 2).toInt()
                        v.layoutParams = lp2
                        zone.x = (lp2.leftMargin + dotSize / 2) / screenW
                        zone.y = (lp2.topMargin + dotSize / 2) / screenH
                        true
                    }
                    MotionEvent.ACTION_UP -> { MappingConfig.save(this); true }
                    else -> true
                }
            }
        }
    }

    private fun hideEditOverlay() {
        editOverlay?.let { wm.removeView(it) }
        editOverlay = null
        MappingConfig.save(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        captureView?.let { runCatching { wm.removeView(it) } }
        toggleBtn?.let { runCatching { wm.removeView(it) } }
        editOverlay?.let { runCatching { wm.removeView(it) } }
    }
}
